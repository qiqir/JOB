'use client'

import { useState, useEffect, useMemo } from 'react'
import { 
  Search, 
  RefreshCw, 
  FileSpreadsheet, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Users,
  TrendingUp,
  BarChart3,
  ExternalLink,
  PlusCircle,
  LayoutDashboard,
  ClipboardCopy,
  Check,
  Send,
  AlertCircle,
  Calendar,
  Pencil,
  MessageCircle,
  Camera,
  User,
  Upload,
  X
} from 'lucide-react'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

interface SheetRow {
  no: string
  tanggal: string
  alamat: string
  namaKlien: string
  noTelephone: string
  jenisPekerjaan: string
  teknisi: string
  statusBa: string
  statusPekerjaan: string
  statusPembayaran: string
  keterangan: string
  rowIndex?: number
}

interface FormData {
  tanggal: string
  alamat: string
  namaKlien: string
  noTelephone: string
  jenisPekerjaan: string
  teknisi: string
  statusBa: string
  statusPekerjaan: string
  statusPembayaran: string
  keterangan: string
}

const COLORS = ['#22c55e', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899']

const getStatusColor = (status: string) => {
  const s = status.toLowerCase()
  if (s.includes('selesai') || s.includes('sudah') || s.includes('lunas') || s.includes('ok')) {
    return 'bg-green-500/10 text-green-600 border-green-200'
  }
  if (s.includes('belum') || s.includes('pending') || s.includes('proses') || s.includes('progress')) {
    return 'bg-yellow-500/10 text-yellow-600 border-yellow-200'
  }
  if (s.includes('batal') || s.includes('gagal') || s.includes('tolak')) {
    return 'bg-red-500/10 text-red-600 border-red-200'
  }
  return 'bg-gray-500/10 text-gray-600 border-gray-200'
}

const STATUS_BA_OPTIONS = ['Sudah', 'Belum', 'Proses']
const STATUS_PEKERJAAN_OPTIONS = ['Selesai', 'Belum Selesai', 'Dalam Proses', 'Pending']
const STATUS_PEMBAYARAN_OPTIONS = ['Lunas', 'Belum Lunas', 'Proses', 'Pending']

// Options for SPPG Jenis Pekerjaan
const JENIS_PEKERJAAN_SPPG_OPTIONS = ['Instalasi Baru', 'Perbaikan', 'Maintenance', 'Relokasi', 'Survey', 'Lainnya']

// Options for User fields
const JABATAN_OPTIONS = ['Admin', 'Teknisi', 'Operator']
const USER_STATUS_OPTIONS = ['Aktiv', 'Tidak Aktiv', 'Blokir']

// Helper function untuk format nomor WhatsApp
const formatWhatsAppNumber = (phone: string): string => {
  if (!phone) return ''
  // Hapus karakter non-digit
  let cleaned = phone.replace(/\D/g, '')
  
  // Jika dimulai dengan 08, ganti dengan 628
  if (cleaned.startsWith('08')) {
    cleaned = '62' + cleaned.substring(1)
  }
  // Jika dimulai dengan +62 atau 62, biarkan
  else if (cleaned.startsWith('62')) {
    // sudah benar
  }
  // Jika tidak ada prefix, tambahkan 62
  else if (cleaned.length > 0) {
    cleaned = '62' + cleaned
  }
  
  return cleaned
}

// Helper function untuk mendapatkan WhatsApp link
const getWhatsAppLink = (phone: string): string => {
  const formatted = formatWhatsAppNumber(phone)
  return `https://wa.me/${formatted}`
}

export default function Dashboard() {
  const [data, setData] = useState<SheetRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatusBa, setFilterStatusBa] = useState<string>('all')
  const [filterStatusPekerjaan, setFilterStatusPekerjaan] = useState<string>('all')
  const [filterStatusPembayaran, setFilterStatusPembayaran] = useState<string>('all')
  const [filterTanggalDari, setFilterTanggalDari] = useState<string>('')
  const [filterTanggalKe, setFilterTanggalKe] = useState<string>('')

  // Auto-sync state
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null)
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true)
  const [syncing, setSyncing] = useState(false)

  // Form state
  const [formData, setFormData] = useState<FormData>({
    tanggal: new Date().toISOString().split('T')[0],
    alamat: '',
    namaKlien: '',
    noTelephone: '',
    jenisPekerjaan: '',
    teknisi: '',
    statusBa: '',
    statusPekerjaan: '',
    statusPembayaran: '',
    keterangan: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState('dashboard')
  
  // Add Dialog state for SPPG
  const [addDialogOpen, setAddDialogOpen] = useState(false)

  // Edit state
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editingRow, setEditingRow] = useState<SheetRow | null>(null)
  const [editFormData, setEditFormData] = useState<FormData>({
    tanggal: '',
    alamat: '',
    namaKlien: '',
    noTelephone: '',
    jenisPekerjaan: '',
    teknisi: '',
    statusBa: '',
    statusPekerjaan: '',
    statusPembayaran: '',
    keterangan: ''
  })
  const [editSubmitting, setEditSubmitting] = useState(false)
  const [editSuccess, setEditSuccess] = useState(false)
  const [editError, setEditError] = useState<string | null>(null)

  // User state
  const [userData, setUserData] = useState<Record<string, string>[]>([])
  const [userHeaders, setUserHeaders] = useState<string[]>([])
  const [userLoading, setUserLoading] = useState(false)
  const [userError, setUserError] = useState<string | null>(null)
  const [userSearchTerm, setUserSearchTerm] = useState('')

  // User Add Dialog state
  const [userAddDialogOpen, setUserAddDialogOpen] = useState(false)
  const [userAddFormData, setUserAddFormData] = useState<Record<string, string>>({})
  const [userAddSubmitting, setUserAddSubmitting] = useState(false)
  const [userAddSuccess, setUserAddSuccess] = useState(false)
  const [userAddError, setUserAddError] = useState<string | null>(null)

  // User Edit Dialog state
  const [userEditDialogOpen, setUserEditDialogOpen] = useState(false)
  const [userEditRowIndex, setUserEditRowIndex] = useState<number>(0)
  const [userEditFormData, setUserEditFormData] = useState<Record<string, string>>({})
  const [userEditSubmitting, setUserEditSubmitting] = useState(false)
  const [userEditSuccess, setUserEditSuccess] = useState(false)
  const [userEditError, setUserEditError] = useState<string | null>(null)

  // User Detail Dialog state (for clickable cards)
  const [userDetailDialogOpen, setUserDetailDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<Record<string, string> | null>(null)
  const [selectedUserIndex, setSelectedUserIndex] = useState<number>(0)
  const [userPhotoUploading, setUserPhotoUploading] = useState(false)
  const [userPhotoError, setUserPhotoError] = useState<string | null>(null)

  const fetchData = async (showSyncIndicator = false) => {
    if (showSyncIndicator) setSyncing(true)
    setError(null)
    try {
      const response = await fetch('/api/sheets')
      const result = await response.json()
      if (result.success) {
        setData(result.data)
        setLastSyncTime(new Date())
      } else {
        setError(result.error || 'Gagal mengambil data')
      }
    } catch {
      setError('Gagal mengambil data dari server')
    } finally {
      setLoading(false)
      setSyncing(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  // Auto-sync interval - sync every 30 seconds
  useEffect(() => {
    if (!autoSyncEnabled) return
    
    const interval = setInterval(() => {
      fetchData(true)
      if (activeTab === 'user') {
        fetchUserData(true)
      }
    }, 30000) // 30 seconds

    return () => clearInterval(interval)
  }, [autoSyncEnabled, activeTab])

  // Fetch USER data
  const fetchUserData = async (showSyncIndicator = false) => {
    if (showSyncIndicator) setSyncing(true)
    setUserError(null)
    try {
      const response = await fetch('/api/sheets/user')
      const result = await response.json()
      if (result.success) {
        setUserData(result.data)
        setUserHeaders(result.headers)
        setLastSyncTime(new Date())
      } else {
        setUserError(result.error || 'Gagal mengambil data USER')
      }
    } catch {
      setUserError('Gagal mengambil data USER dari server')
    } finally {
      setUserLoading(false)
      setSyncing(false)
    }
  }

  // Fetch user data when user tab is selected
  useEffect(() => {
    if (activeTab === 'user' && userData.length === 0) {
      fetchUserData()
    }
  }, [activeTab, userData.length])

  // Manual sync all data
  const syncAllData = async () => {
    setSyncing(true)
    await Promise.all([fetchData(true), fetchUserData(true)])
    setSyncing(false)
  }

  // Get unique values for filters
  const uniqueStatusBa = useMemo(() => {
    const values = new Set(data.map(row => row.statusBa).filter(Boolean))
    return Array.from(values)
  }, [data])

  const uniqueStatusPekerjaan = useMemo(() => {
    const values = new Set(data.map(row => row.statusPekerjaan).filter(Boolean))
    return Array.from(values)
  }, [data])

  const uniqueStatusPembayaran = useMemo(() => {
    const values = new Set(data.map(row => row.statusPembayaran).filter(Boolean))
    return Array.from(values)
  }, [data])

  // Helper function to parse date from various formats
  const parseDate = (dateStr: string): number => {
    if (!dateStr) return 0
    const parts = dateStr.split(/[\/\-\s]/)
    if (parts.length === 3) {
      if (parts[0].length <= 2 && parts[2].length === 4) {
        const day = parseInt(parts[0])
        const month = parseInt(parts[1]) - 1
        const year = parseInt(parts[2])
        return new Date(year, month, day).getTime()
      }
      if (parts[0].length === 4) {
        return new Date(dateStr).getTime()
      }
    }
    return new Date(dateStr).getTime() || 0
  }

  // Filter and sort data - urutkan berdasarkan nomor
  const filteredData = useMemo(() => {
    const filtered = data.filter(row => {
      const matchesSearch = 
        row.alamat.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.namaKlien.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.teknisi.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.noTelephone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.jenisPekerjaan.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.keterangan.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesStatusBa = filterStatusBa === 'all' || row.statusBa === filterStatusBa
      const matchesStatusPekerjaan = filterStatusPekerjaan === 'all' || row.statusPekerjaan === filterStatusPekerjaan
      const matchesStatusPembayaran = filterStatusPembayaran === 'all' || row.statusPembayaran === filterStatusPembayaran

      let matchesTanggal = true
      const rowDate = parseDate(row.tanggal)
      if (filterTanggalDari) {
        const dariDate = new Date(filterTanggalDari).getTime()
        matchesTanggal = matchesTanggal && rowDate >= dariDate
      }
      if (filterTanggalKe) {
        const keDate = new Date(filterTanggalKe).setHours(23, 59, 59, 999)
        matchesTanggal = matchesTanggal && rowDate <= keDate
      }

      return matchesSearch && matchesStatusBa && matchesStatusPekerjaan && matchesStatusPembayaran && matchesTanggal
    })

    return filtered.sort((a, b) => {
      const numA = parseInt(a.no) || 0
      const numB = parseInt(b.no) || 0
      return numA - numB
    })
  }, [data, searchTerm, filterStatusBa, filterStatusPekerjaan, filterStatusPembayaran, filterTanggalDari, filterTanggalKe])

  // Statistics
  const stats = useMemo(() => {
    const total = data.length
    const statusBaStats = new Map<string, number>()
    const statusPekerjaanStats = new Map<string, number>()
    const statusPembayaranStats = new Map<string, number>()
    const teknisiStats = new Map<string, number>()

    data.forEach(row => {
      if (row.statusBa) {
        statusBaStats.set(row.statusBa, (statusBaStats.get(row.statusBa) || 0) + 1)
      }
      if (row.statusPekerjaan) {
        statusPekerjaanStats.set(row.statusPekerjaan, (statusPekerjaanStats.get(row.statusPekerjaan) || 0) + 1)
      }
      if (row.statusPembayaran) {
        statusPembayaranStats.set(row.statusPembayaran, (statusPembayaranStats.get(row.statusPembayaran) || 0) + 1)
      }
      if (row.teknisi) {
        teknisiStats.set(row.teknisi, (teknisiStats.get(row.teknisi) || 0) + 1)
      }
    })

    const selesai = Array.from(statusPekerjaanStats.entries())
      .filter(([key]) => key.toLowerCase().includes('selesai'))
      .reduce((sum, [, val]) => sum + val, 0)
    
    const lunas = Array.from(statusPembayaranStats.entries())
      .filter(([key]) => key.toLowerCase().includes('lunas') || key.toLowerCase().includes('sudah'))
      .reduce((sum, [, val]) => sum + val, 0)

    return {
      total,
      statusBaStats: Array.from(statusBaStats.entries()).map(([name, value]) => ({ name, value })),
      statusPekerjaanStats: Array.from(statusPekerjaanStats.entries()).map(([name, value]) => ({ name, value })),
      statusPembayaranStats: Array.from(statusPembayaranStats.entries()).map(([name, value]) => ({ name, value })),
      teknisiStats: Array.from(teknisiStats.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6),
      selesai,
      lunas,
    }
  }, [data])

  // Form handlers
  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const resetForm = () => {
    setFormData({
      tanggal: new Date().toISOString().split('T')[0],
      alamat: '',
      namaKlien: '',
      noTelephone: '',
      jenisPekerjaan: '',
      teknisi: '',
      statusBa: '',
      statusPekerjaan: '',
      statusPembayaran: '',
      keterangan: ''
    })
    setSubmitSuccess(false)
    setSubmitError(null)
  }

  const generateRowText = () => {
    return `${formData.tanggal}\t${formData.alamat}\t${formData.namaKlien}\t${formData.noTelephone}\t${formData.jenisPekerjaan}\t${formData.teknisi}\t${formData.statusBa}\t${formData.statusPekerjaan}\t${formData.statusPembayaran}\t${formData.keterangan}`
  }

  const copyToClipboard = async () => {
    const rowText = generateRowText()
    await navigator.clipboard.writeText(rowText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setSubmitError(null)
    setSubmitSuccess(false)

    try {
      const response = await fetch('/api/sheets/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      const result = await response.json()

      if (result.success) {
        setSubmitSuccess(true)
        fetchData()
        setTimeout(() => {
          setSubmitSuccess(false)
          setAddDialogOpen(false)
          resetForm()
        }, 2000)
      } else {
        setSubmitError(result.error || 'Gagal menyimpan data')
      }
    } catch {
      setSubmitError('Gagal menghubungi server')
    } finally {
      setSubmitting(false)
    }
  }

  // Edit functions
  const openEditDialog = (row: SheetRow, index: number) => {
    setEditingRow({ ...row, rowIndex: index })
    setEditFormData({
      tanggal: row.tanggal,
      alamat: row.alamat,
      namaKlien: row.namaKlien,
      noTelephone: row.noTelephone,
      jenisPekerjaan: row.jenisPekerjaan,
      teknisi: row.teknisi,
      statusBa: row.statusBa,
      statusPekerjaan: row.statusPekerjaan,
      statusPembayaran: row.statusPembayaran,
      keterangan: row.keterangan
    })
    setEditError(null)
    setEditSuccess(false)
    setEditDialogOpen(true)
  }

  const handleEditInputChange = (field: keyof FormData, value: string) => {
    setEditFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleEditSave = async () => {
    if (!editingRow) return
    
    setEditSubmitting(true)
    setEditError(null)

    // Debug logging
    console.log('=== EDIT SAVE DEBUG ===')
    console.log('editingRow:', editingRow)
    console.log('editingRow.rowIndex:', editingRow.rowIndex)
    console.log('editFormData:', editFormData)
    console.log('======================')

    try {
      const payload = {
        rowIndex: editingRow.rowIndex,
        data: editFormData
      }
      console.log('Sending payload:', JSON.stringify(payload, null, 2))
      
      const response = await fetch('/api/sheets/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      const result = await response.json()
      console.log('Update result:', result)

      if (result.success) {
        setEditSuccess(true)
        setTimeout(() => {
          setEditDialogOpen(false)
          fetchData()
        }, 1500)
      } else {
        setEditError(result.error || 'Gagal mengupdate data')
      }
    } catch (err) {
      console.error('Edit save error:', err)
      setEditError('Gagal menghubungi server')
    } finally {
      setEditSubmitting(false)
    }
  }

  const copyEditToClipboard = async () => {
    const rowText = `${editFormData.tanggal}\t${editFormData.alamat}\t${editFormData.namaKlien}\t${editFormData.noTelephone}\t${editFormData.jenisPekerjaan}\t${editFormData.teknisi}\t${editFormData.statusBa}\t${editFormData.statusPekerjaan}\t${editFormData.statusPembayaran}\t${editFormData.keterangan}`
    await navigator.clipboard.writeText(rowText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // User Add functions
  const openUserAddDialog = () => {
    const initialData: Record<string, string> = {}
    userHeaders.forEach(header => {
      initialData[header] = ''
    })
    setUserAddFormData(initialData)
    setUserAddError(null)
    setUserAddSuccess(false)
    setUserAddDialogOpen(true)
  }

  const handleUserAddInputChange = (header: string, value: string) => {
    setUserAddFormData(prev => ({ ...prev, [header]: value }))
  }

  const handleUserAddSubmit = async () => {
    setUserAddSubmitting(true)
    setUserAddError(null)

    try {
      const dataArray = userHeaders.map(header => userAddFormData[header] || '')
      
      const response = await fetch('/api/sheets/user/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          data: dataArray,
          headers: userHeaders
        })
      })
      const result = await response.json()

      if (result.success) {
        setUserAddSuccess(true)
        fetchUserData()
        setTimeout(() => {
          setUserAddDialogOpen(false)
          setUserAddSuccess(false)
        }, 2000)
      } else {
        setUserAddError(result.error || 'Gagal menyimpan data. Pastikan Google Script URL belum dikonfigurasi.')
      }
    } catch {
      setUserAddError('Gagal menghubungi server')
    } finally {
      setUserAddSubmitting(false)
    }
  }

  // User Edit functions
  const openUserEditDialog = (row: Record<string, string>, index: number) => {
    setUserEditRowIndex(index)
    const editData: Record<string, string> = {}
    userHeaders.forEach(header => {
      const key = header.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
      editData[header] = row[key] || ''
    })
    setUserEditFormData(editData)
    setUserEditError(null)
    setUserEditSuccess(false)
    setUserEditDialogOpen(true)
  }

  const handleUserEditInputChange = (header: string, value: string) => {
    setUserEditFormData(prev => ({ ...prev, [header]: value }))
  }

  const handleUserEditSubmit = async () => {
    setUserEditSubmitting(true)
    setUserEditError(null)

    try {
      const dataArray = userHeaders.map(header => userEditFormData[header] || '')
      const response = await fetch('/api/sheets/user/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rowIndex: userEditRowIndex, data: dataArray })
      })
      const result = await response.json()

      if (result.success) {
        setUserEditSuccess(true)
        fetchUserData()
        setTimeout(() => {
          setUserEditDialogOpen(false)
          setUserEditSuccess(false)
        }, 2000)
      } else {
        setUserEditError(result.error || 'Gagal menyimpan data')
      }
    } catch {
      setUserEditError('Gagal menghubungi server')
    } finally {
      setUserEditSubmitting(false)
    }
  }

  // User Detail functions (for clickable cards)
  const openUserDetailDialog = (row: Record<string, string>, index: number) => {
    setSelectedUser(row)
    setSelectedUserIndex(index)
    setUserPhotoError(null)
    setUserDetailDialogOpen(true)
  }

  // Photo upload function
  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file || !selectedUser) return

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setUserPhotoError('File harus berupa gambar')
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUserPhotoError('Ukuran file maksimal 5MB')
      return
    }

    setUserPhotoUploading(true)
    setUserPhotoError(null)

    try {
      const formData = new FormData()
      formData.append('photo', file)
      formData.append('userIndex', String(selectedUserIndex))
      formData.append('userName', getUserName(selectedUser))

      const response = await fetch('/api/sheets/user/photo', {
        method: 'POST',
        body: formData
      })
      const result = await response.json()

      if (result.success) {
        // Find the photo column key from userHeaders
        let photoKey = 'photo'
        for (const header of userHeaders) {
          const key = header.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
          if (key.includes('photo') || key.includes('foto') || key.includes('gambar')) {
            photoKey = key
            break
          }
        }
        
        // Update selected user with new photo URL immediately
        if (result.photoUrl) {
          setSelectedUser(prev => prev ? { ...prev, [photoKey]: result.photoUrl } : null)
        }
        
        // Refresh user data from sheet
        fetchUserData()
      } else {
        setUserPhotoError(result.error || 'Gagal mengupload foto')
      }
    } catch {
      setUserPhotoError('Gagal menghubungi server')
    } finally {
      setUserPhotoUploading(false)
    }
  }

  // Helper function to get user name from row data
  const getUserName = (row: Record<string, string>): string => {
    // Try to find name column
    const nameKeys = ['nama', 'name', 'nama_user', 'username']
    for (const key of nameKeys) {
      for (const rowKey of Object.keys(row)) {
        if (rowKey.toLowerCase().includes(key)) {
          return row[rowKey] || 'MBG'
        }
      }
    }
    return 'MBG'
  }

  // Helper function to get user photo URL
  const getUserPhoto = (row: Record<string, string>): string => {
    // Check for photo_url column - normalize key comparison
    const photoKeys = ['photo_url', 'photo', 'foto', 'foto_url', 'gambar', 'image_url', 'link_foto', 'link_photo']
    for (const key of photoKeys) {
      for (const rowKey of Object.keys(row)) {
        if (rowKey.toLowerCase().includes(key)) {
          let url = row[rowKey]
          if (url && url.trim() && url.startsWith('http')) {
            // For Google Drive URLs, ensure we use the view format
            if (url.includes('drive.google.com')) {
              // Extract file ID from various Google Drive URL formats
              let fileId = ''
              if (url.includes('id=')) {
                fileId = url.split('id=')[1].split('&')[0]
              } else if (url.includes('/d/')) {
                fileId = url.split('/d/')[1].split('/')[0]
              }
              if (fileId) {
                // Use export=view for displaying images (better than download)
                return `https://drive.google.com/uc?export=view&id=${fileId}`
              }
            }
            return url
          }
          if (url && url.startsWith('data:')) {
            return url
          }
        }
      }
    }
    return '' // Return empty string if no photo found
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg">
                <FileSpreadsheet className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 dark:text-white">Dashboard SPPG</h1>
                <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                  <span>Monitoring Data SPPG</span>
                  {lastSyncTime && (
                    <span className="text-xs text-slate-400 dark:text-slate-500">
                      • Sync: {lastSyncTime.toLocaleTimeString('id-ID')}
                    </span>
                  )}
                  {syncing && (
                    <span className="flex items-center gap-1 text-xs text-blue-500">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Syncing...
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Auto-sync toggle */}
              <Button
                variant={autoSyncEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoSyncEnabled(!autoSyncEnabled)}
                className={`gap-2 ${autoSyncEnabled ? 'bg-green-600 hover:bg-green-700' : ''}`}
              >
                {autoSyncEnabled ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    Auto-Sync ON
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4" />
                    Auto-Sync OFF
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={syncAllData}
                disabled={syncing}
                className="gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
                Sync Now
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open('https://docs.google.com/spreadsheets/d/1Ntfc9QLJs6Al2nEHtydMiVurGTpwJLILUFjOQ1QyGXg/edit', '_blank')}
                className="gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                Buka Sheet
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="dashboard" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="user" className="gap-2">
              <Users className="w-4 h-4" />
              User
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            {/* Error Message */}
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 text-red-700 dark:text-red-300">
                {error}
              </div>
            )}

            {/* Data Table - Paling Atas */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Data SPPG</CardTitle>
                    <CardDescription>
                      Menampilkan {filteredData.length} dari {data.length} data
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => setAddDialogOpen(true)}
                    className="gap-2"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Tambah Data
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filter */}
                <div className="space-y-4 mb-6 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <Input
                        placeholder="Cari nama, teknisi..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Select value={filterStatusBa} onValueChange={setFilterStatusBa}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Status BA" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status BA</SelectItem>
                        {uniqueStatusBa.map((status) => (
                          <SelectItem key={status} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={filterStatusPekerjaan} onValueChange={setFilterStatusPekerjaan}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Status Pekerjaan" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status Pekerjaan</SelectItem>
                        {uniqueStatusPekerjaan.map((status) => (
                          <SelectItem key={status} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={filterStatusPembayaran} onValueChange={setFilterStatusPembayaran}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Status Pembayaran" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status Pembayaran</SelectItem>
                        {uniqueStatusPembayaran.map((status) => (
                          <SelectItem key={status} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div className="space-y-2">
                      <Label className="text-sm text-slate-500 flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Dari Tanggal
                      </Label>
                      <Input
                        type="date"
                        value={filterTanggalDari}
                        onChange={(e) => setFilterTanggalDari(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm text-slate-500 flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Ke Tanggal
                      </Label>
                      <Input
                        type="date"
                        value={filterTanggalKe}
                        onChange={(e) => setFilterTanggalKe(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setFilterTanggalDari('')
                        setFilterTanggalKe('')
                      }}
                      className="w-full md:w-auto"
                    >
                      Reset Tanggal
                    </Button>
                  </div>
                </div>

                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <RefreshCw className="w-8 h-8 animate-spin text-slate-400" />
                  </div>
                ) : filteredData.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                    <XCircle className="w-12 h-12 mb-4 text-slate-300" />
                    <p>Tidak ada data yang ditemukan</p>
                  </div>
                ) : (
                  <div className="border rounded-lg overflow-hidden">
                    <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
                      <Table>
                        <TableHeader className="sticky top-0 bg-white dark:bg-slate-900 z-10">
                          <TableRow>
                            <TableHead className="w-12 text-center">No</TableHead>
                            <TableHead className="min-w-[100px]">Tanggal</TableHead>
                            <TableHead className="min-w-[180px]">Alamat</TableHead>
                            <TableHead className="min-w-[130px]">Nama Klien</TableHead>
                            <TableHead className="min-w-[120px]">No. Telepon</TableHead>
                            <TableHead className="min-w-[130px]">Jenis Pekerjaan</TableHead>
                            <TableHead className="min-w-[100px]">Teknisi</TableHead>
                            <TableHead className="min-w-[90px]">Status BA</TableHead>
                            <TableHead className="min-w-[120px]">Status Pekerjaan</TableHead>
                            <TableHead className="min-w-[120px]">Status Pembayaran</TableHead>
                            <TableHead className="min-w-[150px]">Keterangan</TableHead>
                            <TableHead className="w-16 text-center sticky right-0 bg-white dark:bg-slate-900">Aksi</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredData.map((row, index) => {
                            const originalIndex = data.findIndex(d => 
                              d.no === row.no && 
                              d.tanggal === row.tanggal && 
                              d.alamat === row.alamat
                            )
                            return (
                              <TableRow key={index} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                <TableCell className="font-medium text-center">{row.no || index + 1}</TableCell>
                                <TableCell className="whitespace-nowrap">{row.tanggal}</TableCell>
                                <TableCell className="font-medium whitespace-nowrap">{row.alamat}</TableCell>
                                <TableCell className="whitespace-nowrap">{row.namaKlien}</TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <div className="flex items-center gap-2">
                                    <a 
                                      href={`tel:${row.noTelephone}`} 
                                      className="text-blue-600 hover:underline"
                                    >
                                      {row.noTelephone}
                                    </a>
                                    {row.noTelephone && (
                                      <a
                                        href={getWhatsAppLink(row.noTelephone)}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-green-600 hover:text-green-700"
                                        title="Hubungi via WhatsApp"
                                      >
                                        <MessageCircle className="w-4 h-4" />
                                      </a>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell className="whitespace-nowrap">{row.jenisPekerjaan || '-'}</TableCell>
                                <TableCell className="whitespace-nowrap">{row.teknisi}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className={getStatusColor(row.statusBa)}>
                                    {row.statusBa || '-'}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline" className={getStatusColor(row.statusPekerjaan)}>
                                    {row.statusPekerjaan || '-'}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline" className={getStatusColor(row.statusPembayaran)}>
                                    {row.statusPembayaran || '-'}
                                  </Badge>
                                </TableCell>
                                <TableCell className="max-w-[200px]">
                                  <span className="line-clamp-2" title={row.keterangan}>
                                    {row.keterangan || '-'}
                                  </span>
                                </TableCell>
                                <TableCell className="text-center sticky right-0 bg-white dark:bg-slate-900">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => openEditDialog(row, originalIndex)}
                                    className="h-8 w-8 p-0"
                                  >
                                    <Pencil className="w-4 h-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
                <CardHeader className="pb-2">
                  <CardDescription className="text-blue-100">Total Data</CardDescription>
                  <CardTitle className="text-3xl font-bold">{stats.total}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-blue-100 text-sm">
                    <Users className="w-4 h-4" />
                    <span>Semua SPPG</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-0">
                <CardHeader className="pb-2">
                  <CardDescription className="text-emerald-100">Pekerjaan Selesai</CardDescription>
                  <CardTitle className="text-3xl font-bold">{stats.selesai}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-emerald-100 text-sm">
                    <CheckCircle className="w-4 h-4" />
                    <span>{stats.total > 0 ? ((stats.selesai / stats.total) * 100).toFixed(1) : 0}% selesai</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-violet-500 to-violet-600 text-white border-0">
                <CardHeader className="pb-2">
                  <CardDescription className="text-violet-100">Pembayaran Lunas</CardDescription>
                  <CardTitle className="text-3xl font-bold">{stats.lunas}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-violet-100 text-sm">
                    <TrendingUp className="w-4 h-4" />
                    <span>{stats.total > 0 ? ((stats.lunas / stats.total) * 100).toFixed(1) : 0}% lunas</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-500 to-orange-500 text-white border-0">
                <CardHeader className="pb-2">
                  <CardDescription className="text-amber-100">Dalam Proses</CardDescription>
                  <CardTitle className="text-3xl font-bold">{stats.total - stats.selesai}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-amber-100 text-sm">
                    <Clock className="w-4 h-4" />
                    <span>Sedang berjalan</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Status Pekerjaan
                  </CardTitle>
                  <CardDescription>Distribusi status pekerjaan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats.statusPekerjaanStats} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Status Pembayaran
                  </CardTitle>
                  <CardDescription>Distribusi status pembayaran</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={stats.statusPembayaranStats}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          dataKey="value"
                          label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                          labelLine={false}
                        >
                          {stats.statusPembayaranStats.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Teknisi Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Performa Teknisi</CardTitle>
                <CardDescription>Jumlah pekerjaan per teknisi (Top 6)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.teknisiStats}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Tab */}
          <TabsContent value="user" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5" />
                      Data SHEET_USER
                    </CardTitle>
                    <CardDescription>
                      Data dari Google Sheet - SHEET_USER
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={openUserAddDialog}
                      className="gap-2"
                    >
                      <PlusCircle className="w-4 h-4" />
                      Tambah Data
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Search */}
                <div className="mb-4">
                  <div className="relative w-full md:w-80">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      placeholder="Cari data USER..."
                      value={userSearchTerm}
                      onChange={(e) => setUserSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {userError && (
                  <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4 mb-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-amber-800 dark:text-amber-200">Konfigurasi Diperlukan</p>
                        <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">{userError}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Loading */}
                {userLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <RefreshCw className="w-8 h-8 animate-spin text-slate-400" />
                  </div>
                ) : !userError && userData.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                    <Users className="w-12 h-12 mb-4 text-slate-300" />
                    <p>Tidak ada data ditemukan</p>
                  </div>
                ) : !userError && userData.length > 0 ? (
                  <>
                    {/* Card Grid Layout with Photo Frames */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                      {userData
                        .filter(row => {
                          if (!userSearchTerm) return true
                          return Object.values(row).some(val => 
                            val.toLowerCase().includes(userSearchTerm.toLowerCase())
                          )
                        })
                        .map((row, index) => {
                          const photoUrl = getUserPhoto(row)
                          const userName = getUserName(row)
                          // Get phone number for WhatsApp
                          let phoneNumber = ''
                          for (const header of userHeaders) {
                            const key = header.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
                            if (header.toLowerCase().includes('telepon') || 
                                header.toLowerCase().includes('telp') ||
                                header.toLowerCase().includes('phone') ||
                                header.toLowerCase().includes('hp') ||
                                header.toLowerCase().includes('no ')) {
                              phoneNumber = row[key] || ''
                              break
                            }
                          }
                          
                          return (
                            <div
                              key={index}
                              onClick={() => openUserDetailDialog(row, index)}
                              className="bg-white dark:bg-slate-800 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer border border-slate-200 dark:border-slate-700 overflow-hidden group"
                            >
                              {/* Photo Frame */}
                              <div className="relative aspect-square bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 flex items-center justify-center overflow-hidden">
                                {photoUrl ? (
                                  <img
                                    src={photoUrl}
                                    alt={userName}
                                    referrerPolicy="no-referrer"
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    onError={(e) => {
                                      // Try alternative URL formats on error
                                      const target = e.target as HTMLImageElement
                                      const currentSrc = target.src
                                      
                                      // If this is a Google Drive URL that failed
                                      if (currentSrc.includes('drive.google.com')) {
                                        const match = currentSrc.match(/id=([^&]+)/)
                                        if (match) {
                                          const fileId = match[1]
                                          // Try Google's thumbnail service as fallback
                                          if (!currentSrc.includes('lh3.googleusercontent.com')) {
                                            target.src = `https://lh3.googleusercontent.com/d/${fileId}=w400-h400-n-rw`
                                          } else {
                                            // Last resort: hide the image
                                            target.style.display = 'none'
                                          }
                                        }
                                      }
                                    }}
                                    onLoad={(e) => {
                                      // Ensure image is visible on successful load
                                      const target = e.target as HTMLImageElement
                                      target.style.display = 'block'
                                    }}
                                  />
                                ) : (
                                  <div className="flex flex-col items-center justify-center text-slate-400 dark:text-slate-500">
                                    <User className="w-16 h-16 mb-2" />
                                    <Camera className="w-6 h-6" />
                                    <span className="text-xs mt-1">Klik untuk tambah foto</span>
                                  </div>
                                )}
                                {/* Overlay on hover */}
                                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
                                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                    <div className="bg-white/90 dark:bg-slate-800/90 rounded-full p-3 shadow-lg">
                                      <Camera className="w-6 h-6 text-slate-700 dark:text-slate-200" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              {/* User Info */}
                              <div className="p-3">
                                <h3 className="font-semibold text-slate-900 dark:text-white truncate" title={userName}>
                                  {userName || `User ${index + 1}`}
                                </h3>
                                {phoneNumber && (
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-sm text-slate-500 dark:text-slate-400 truncate">
                                      {phoneNumber}
                                    </span>
                                    <a
                                      href={getWhatsAppLink(phoneNumber)}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      onClick={(e) => e.stopPropagation()}
                                      className="text-green-600 hover:text-green-700 flex-shrink-0"
                                      title="Hubungi via WhatsApp"
                                    >
                                      <MessageCircle className="w-4 h-4" />
                                    </a>
                                  </div>
                                )}
                              </div>
                            </div>
                          )
                        })}
                    </div>
                    
                    {/* Total count */}
                    <div className="mt-4 text-sm text-slate-500 dark:text-slate-400">
                      Total: {userData.filter(row => {
                        if (!userSearchTerm) return true
                        return Object.values(row).some(val => 
                          val.toLowerCase().includes(userSearchTerm.toLowerCase())
                        )
                      }).length} data
                    </div>
                  </>
                ) : null}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Dialog for SPPG */}
        <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5" />
                Tambah Data SPPG
              </DialogTitle>
              <DialogDescription>
                Masukkan data SPPG baru untuk disimpan ke database.
              </DialogDescription>
            </DialogHeader>

            {submitSuccess && (
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3 text-green-700 dark:text-green-300">
                <CheckCircle className="w-5 h-5" />
                <span>Data berhasil disimpan!</span>
              </div>
            )}

            {submitError && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-center gap-3 text-red-700 dark:text-red-300">
                <AlertCircle className="w-5 h-5" />
                <span>{submitError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="add-tanggal" className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    Tanggal
                  </Label>
                  <Input
                    id="add-tanggal"
                    type="date"
                    value={formData.tanggal}
                    onChange={(e) => handleInputChange('tanggal', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-alamat">Alamat</Label>
                  <Input
                    id="add-alamat"
                    placeholder="Alamat pekerjaan"
                    value={formData.alamat}
                    onChange={(e) => handleInputChange('alamat', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-namaKlien">Nama Klien</Label>
                  <Input
                    id="add-namaKlien"
                    placeholder="Nama Klien"
                    value={formData.namaKlien}
                    onChange={(e) => handleInputChange('namaKlien', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-noTelephone">No. Telepon</Label>
                  <Input
                    id="add-noTelephone"
                    type="tel"
                    placeholder="08xxxxxxxxxx"
                    value={formData.noTelephone}
                    onChange={(e) => handleInputChange('noTelephone', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-jenisPekerjaan">Jenis Pekerjaan</Label>
                  <Select 
                    value={formData.jenisPekerjaan} 
                    onValueChange={(value) => handleInputChange('jenisPekerjaan', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih jenis pekerjaan" />
                    </SelectTrigger>
                    <SelectContent>
                      {JENIS_PEKERJAAN_SPPG_OPTIONS.map((jenis) => (
                        <SelectItem key={jenis} value={jenis}>
                          {jenis}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-teknisi">Teknisi</Label>
                  <Input
                    id="add-teknisi"
                    placeholder="Nama Teknisi"
                    value={formData.teknisi}
                    onChange={(e) => handleInputChange('teknisi', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-statusBa">Status BA</Label>
                  <Select 
                    value={formData.statusBa} 
                    onValueChange={(value) => handleInputChange('statusBa', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih status BA" />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_BA_OPTIONS.map((status) => (
                        <SelectItem key={status} value={status}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-statusPekerjaan">Status Pekerjaan</Label>
                  <Select 
                    value={formData.statusPekerjaan} 
                    onValueChange={(value) => handleInputChange('statusPekerjaan', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih status pekerjaan" />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_PEKERJAAN_OPTIONS.map((status) => (
                        <SelectItem key={status} value={status}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="add-statusPembayaran">Status Pembayaran</Label>
                  <Select 
                    value={formData.statusPembayaran} 
                    onValueChange={(value) => handleInputChange('statusPembayaran', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih status pembayaran" />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_PEMBAYARAN_OPTIONS.map((status) => (
                        <SelectItem key={status} value={status}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="add-keterangan">Keterangan</Label>
                <Textarea
                  id="add-keterangan"
                  placeholder="Keterangan tambahan (opsional)"
                  value={formData.keterangan}
                  onChange={(e) => handleInputChange('keterangan', e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex flex-wrap gap-3 pt-4">
                <Button type="submit" disabled={submitting} className="gap-2">
                  <Send className="w-4 h-4" />
                  {submitting ? 'Menyimpan...' : 'Simpan Data'}
                </Button>
                <Button type="button" variant="outline" onClick={copyToClipboard} className="gap-2">
                  {copied ? <Check className="w-4 h-4" /> : <ClipboardCopy className="w-4 h-4" />}
                  {copied ? 'Tersalin!' : 'Salin'}
                </Button>
                <Button type="button" variant="ghost" onClick={() => { setAddDialogOpen(false); resetForm(); }}>
                  Batal
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog for SPPG */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Pencil className="w-5 h-5" />
                Edit Data SPPG
              </DialogTitle>
              <DialogDescription>
                Ubah data SPPG sesuai kebutuhan
              </DialogDescription>
            </DialogHeader>

            {editSuccess && (
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3 text-green-700 dark:text-green-300">
                <CheckCircle className="w-5 h-5" />
                <span>Data berhasil diupdate!</span>
              </div>
            )}

            {editError && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-center gap-3 text-red-700 dark:text-red-300">
                <AlertCircle className="w-5 h-5" />
                <span>{editError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-tanggal">Tanggal</Label>
                <Input
                  id="edit-tanggal"
                  type="date"
                  value={editFormData.tanggal}
                  disabled
                  className="bg-slate-100 dark:bg-slate-800 cursor-not-allowed"
                />
                <p className="text-xs text-slate-500">Tanggal tidak dapat diubah</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-alamat">Alamat</Label>
                <Input
                  id="edit-alamat"
                  value={editFormData.alamat}
                  onChange={(e) => handleEditInputChange('alamat', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-namaKlien">Nama Klien</Label>
                <Input
                  id="edit-namaKlien"
                  value={editFormData.namaKlien}
                  onChange={(e) => handleEditInputChange('namaKlien', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-noTelephone">No. Telepon</Label>
                <Input
                  id="edit-noTelephone"
                  value={editFormData.noTelephone}
                  onChange={(e) => handleEditInputChange('noTelephone', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-jenisPekerjaan">Jenis Pekerjaan</Label>
                <Select 
                  value={editFormData.jenisPekerjaan} 
                  onValueChange={(value) => handleEditInputChange('jenisPekerjaan', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih jenis pekerjaan" />
                  </SelectTrigger>
                  <SelectContent>
                    {JENIS_PEKERJAAN_SPPG_OPTIONS.map((jenis) => (
                      <SelectItem key={jenis} value={jenis}>
                        {jenis}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-teknisi">Teknisi</Label>
                <Input
                  id="edit-teknisi"
                  value={editFormData.teknisi}
                  onChange={(e) => handleEditInputChange('teknisi', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-statusBa">Status BA</Label>
                <Select 
                  value={editFormData.statusBa} 
                  onValueChange={(value) => handleEditInputChange('statusBa', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status BA" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_BA_OPTIONS.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-statusPekerjaan">Status Pekerjaan</Label>
                <Select 
                  value={editFormData.statusPekerjaan} 
                  onValueChange={(value) => handleEditInputChange('statusPekerjaan', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status pekerjaan" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_PEKERJAAN_OPTIONS.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-statusPembayaran">Status Pembayaran</Label>
                <Select 
                  value={editFormData.statusPembayaran} 
                  onValueChange={(value) => handleEditInputChange('statusPembayaran', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status pembayaran" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_PEMBAYARAN_OPTIONS.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-keterangan">Keterangan</Label>
              <Textarea
                id="edit-keterangan"
                value={editFormData.keterangan}
                onChange={(e) => handleEditInputChange('keterangan', e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex flex-wrap gap-3 pt-4">
              <Button onClick={handleEditSave} disabled={editSubmitting} className="gap-2">
                <Pencil className="w-4 h-4" />
                {editSubmitting ? 'Menyimpan...' : 'Simpan Perubahan'}
              </Button>
              <Button variant="outline" onClick={copyEditToClipboard} className="gap-2">
                {copied ? <Check className="w-4 h-4" /> : <ClipboardCopy className="w-4 h-4" />}
                {copied ? 'Tersalin!' : 'Salin ke Clipboard'}
              </Button>
              <Button variant="ghost" onClick={() => setEditDialogOpen(false)}>
                Batal
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* User Add Dialog */}
        <Dialog open={userAddDialogOpen} onOpenChange={setUserAddDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5" />
                Tambah Data User
              </DialogTitle>
              <DialogDescription>
                Masukkan data user baru untuk disimpan langsung ke database.
              </DialogDescription>
            </DialogHeader>

            {userAddSuccess && (
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3 text-green-700 dark:text-green-300">
                <CheckCircle className="w-5 h-5" />
                <span>Data berhasil disimpan!</span>
              </div>
            )}

            {userAddError && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-center gap-3 text-red-700 dark:text-red-300">
                <AlertCircle className="w-5 h-5" />
                <span>{userAddError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              {userHeaders.map((header, idx) => {
                const headerLower = header.toLowerCase()
                const isJabatanColumn = headerLower.includes('jabatan') || headerLower.includes('role') || headerLower.includes('posisi')
                const isStatusColumn = headerLower.includes('status') && !headerLower.includes('pekerjaan') && !headerLower.includes('pembayaran')
                const isPhotoColumn = headerLower.includes('photo') || headerLower.includes('foto') || headerLower.includes('gambar')
                
                // Skip photo column in add form
                if (isPhotoColumn) return null
                
                return (
                  <div key={idx} className="space-y-2">
                    <Label htmlFor={`user-add-${idx}`}>{header}</Label>
                    {isJabatanColumn ? (
                      <Select 
                        value={userAddFormData[header] || ''} 
                        onValueChange={(value) => handleUserAddInputChange(header, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih jabatan" />
                        </SelectTrigger>
                        <SelectContent>
                          {JABATAN_OPTIONS.map((jabatan) => (
                            <SelectItem key={jabatan} value={jabatan}>
                              {jabatan}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : isStatusColumn ? (
                      <Select 
                        value={userAddFormData[header] || ''} 
                        onValueChange={(value) => handleUserAddInputChange(header, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih status" />
                        </SelectTrigger>
                        <SelectContent>
                          {USER_STATUS_OPTIONS.map((status) => (
                            <SelectItem key={status} value={status}>
                              {status}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input
                        id={`user-add-${idx}`}
                        placeholder={`Masukkan ${header}`}
                        value={userAddFormData[header] || ''}
                        onChange={(e) => handleUserAddInputChange(header, e.target.value)}
                      />
                    )}
                  </div>
                )
              })}
            </div>

            <div className="flex flex-wrap gap-3 pt-4">
              <Button onClick={handleUserAddSubmit} disabled={userAddSubmitting} className="gap-2">
                <Send className="w-4 h-4" />
                {userAddSubmitting ? 'Menyimpan...' : 'Simpan Data'}
              </Button>
              <Button variant="ghost" onClick={() => setUserAddDialogOpen(false)}>
                Batal
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* User Edit Dialog */}
        <Dialog open={userEditDialogOpen} onOpenChange={setUserEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Pencil className="w-5 h-5" />
                Edit Data User
              </DialogTitle>
              <DialogDescription>
                Ubah data user sesuai kebutuhan. Data akan disimpan langsung ke Google Sheet.
              </DialogDescription>
            </DialogHeader>

            {userEditSuccess && (
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3 text-green-700 dark:text-green-300">
                <CheckCircle className="w-5 h-5" />
                <span>Data berhasil disimpan!</span>
              </div>
            )}

            {userEditError && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-center gap-3 text-red-700 dark:text-red-300">
                <AlertCircle className="w-5 h-5" />
                <span>{userEditError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              {userHeaders.map((header, idx) => {
                const headerLower = header.toLowerCase()
                const isJabatanColumn = headerLower.includes('jabatan') || headerLower.includes('role') || headerLower.includes('posisi')
                const isStatusColumn = headerLower.includes('status') && !headerLower.includes('pekerjaan') && !headerLower.includes('pembayaran')
                const isPhotoColumn = headerLower.includes('photo') || headerLower.includes('foto') || headerLower.includes('gambar')
                
                // Skip photo column in edit form
                if (isPhotoColumn) return null
                
                return (
                  <div key={idx} className="space-y-2">
                    <Label htmlFor={`user-edit-${idx}`}>{header}</Label>
                    {isJabatanColumn ? (
                      <Select 
                        value={userEditFormData[header] || ''} 
                        onValueChange={(value) => handleUserEditInputChange(header, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih jabatan" />
                        </SelectTrigger>
                        <SelectContent>
                          {JABATAN_OPTIONS.map((jabatan) => (
                            <SelectItem key={jabatan} value={jabatan}>
                              {jabatan}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : isStatusColumn ? (
                      <Select 
                        value={userEditFormData[header] || ''} 
                        onValueChange={(value) => handleUserEditInputChange(header, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih status" />
                        </SelectTrigger>
                        <SelectContent>
                          {USER_STATUS_OPTIONS.map((status) => (
                            <SelectItem key={status} value={status}>
                              {status}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input
                        id={`user-edit-${idx}`}
                        placeholder={`Masukkan ${header}`}
                        value={userEditFormData[header] || ''}
                        onChange={(e) => handleUserEditInputChange(header, e.target.value)}
                      />
                    )}
                  </div>
                )
              })}
            </div>

            <div className="flex flex-wrap gap-3 pt-4">
              <Button onClick={handleUserEditSubmit} disabled={userEditSubmitting} className="gap-2">
                <Send className="w-4 h-4" />
                {userEditSubmitting ? 'Menyimpan...' : 'Simpan Data'}
              </Button>
              <Button variant="ghost" onClick={() => setUserEditDialogOpen(false)}>
                Batal
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* User Detail Dialog with Photo */}
        <Dialog open={userDetailDialogOpen} onOpenChange={setUserDetailDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Detail User
              </DialogTitle>
              <DialogDescription>
                Lihat detail user dan kelola foto profil
              </DialogDescription>
            </DialogHeader>

            {userPhotoError && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-center gap-3 text-red-700 dark:text-red-300">
                <AlertCircle className="w-5 h-5" />
                <span>{userPhotoError}</span>
              </div>
            )}

            {selectedUser && (
              <div className="py-4">
                {/* Photo Frame */}
                <div className="relative w-48 h-48 mx-auto mb-6 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 rounded-xl overflow-hidden border-4 border-white dark:border-slate-700 shadow-lg">
                  {getUserPhoto(selectedUser) ? (
                    <img
                      src={getUserPhoto(selectedUser)}
                      alt={getUserName(selectedUser)}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement
                        const currentSrc = target.src
                        
                        // If this is a Google Drive URL that failed
                        if (currentSrc.includes('drive.google.com')) {
                          const match = currentSrc.match(/id=([^&]+)/)
                          if (match) {
                            const fileId = match[1]
                            // Try Google's thumbnail service as fallback
                            if (!currentSrc.includes('lh3.googleusercontent.com')) {
                              target.src = `https://lh3.googleusercontent.com/d/${fileId}=w400-h400-n-rw`
                            }
                          }
                        }
                      }}
                      onLoad={(e) => {
                        const target = e.target as HTMLImageElement
                        target.style.display = 'block'
                      }}
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-400 dark:text-slate-500">
                      <User className="w-20 h-20" />
                      <span className="text-sm mt-2">Tidak ada foto</span>
                    </div>
                  )}
                  
                  {/* Photo upload overlay */}
                  <label className="absolute inset-0 bg-black/50 flex items-center justify-center cursor-pointer opacity-0 hover:opacity-100 transition-opacity">
                    <div className="text-white text-center">
                      {userPhotoUploading ? (
                        <RefreshCw className="w-8 h-8 mx-auto animate-spin" />
                      ) : (
                        <>
                          <Camera className="w-8 h-8 mx-auto mb-2" />
                          <span className="text-sm">Ganti Foto</span>
                        </>
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handlePhotoUpload}
                      disabled={userPhotoUploading}
                    />
                  </label>
                </div>

                {/* Upload Photo Button */}
                <div className="flex justify-center mb-6">
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handlePhotoUpload}
                      disabled={userPhotoUploading}
                    />
                    <Button variant="outline" className="gap-2" disabled={userPhotoUploading} asChild>
                      <span>
                        <Upload className="w-4 h-4" />
                        {userPhotoUploading ? 'Mengupload...' : 'Upload Foto'}
                      </span>
                    </Button>
                  </label>
                </div>

                {/* User Details */}
                <div className="space-y-3">
                  {userHeaders.map((header, idx) => {
                    const key = header.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
                    const value = selectedUser[key] || '-'
                    const isPhoneColumn = header.toLowerCase().includes('telepon') || 
                                          header.toLowerCase().includes('telp') ||
                                          header.toLowerCase().includes('phone') ||
                                          header.toLowerCase().includes('hp') ||
                                          header.toLowerCase().includes('no ')
                    const isPhotoColumn = header.toLowerCase().includes('photo') || 
                                          header.toLowerCase().includes('foto') ||
                                          header.toLowerCase().includes('gambar')
                    
                    // Skip photo column in detail view
                    if (isPhotoColumn) return null
                    
                    return (
                      <div key={idx} className="flex justify-between items-start py-2 border-b border-slate-100 dark:border-slate-700 last:border-0">
                        <span className="text-sm font-medium text-slate-500 dark:text-slate-400">{header}</span>
                        <span className="text-sm text-slate-900 dark:text-white text-right max-w-[60%] break-words">
                          {isPhoneColumn && value !== '-' ? (
                            <div className="flex items-center gap-2 justify-end">
                              <a 
                                href={`tel:${value}`}
                                className="text-blue-600 hover:underline"
                              >
                                {value}
                              </a>
                              <a
                                href={getWhatsAppLink(value)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-green-600 hover:text-green-700"
                                title="Hubungi via WhatsApp"
                              >
                                <MessageCircle className="w-4 h-4" />
                              </a>
                            </div>
                          ) : value}
                        </span>
                      </div>
                    )
                  })}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 mt-6">
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    onClick={() => {
                      setUserDetailDialogOpen(false)
                      openUserEditDialog(selectedUser, selectedUserIndex)
                    }}
                  >
                    <Pencil className="w-4 h-4" />
                    Edit Data
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setUserDetailDialogOpen(false)}
                  >
                    Tutup
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
