import { NextResponse } from 'next/server'

// Google Apps Script Web App URL
const GOOGLE_SCRIPT_URL = process.env.GOOGLE_SCRIPT_URL || 'https://script.google.com/macros/s/AKfycbxs9WTyBb0-yNAtcw_srfqXzooReBFPLkIqsi6Ii5YtQWEzQCgxhMdS49qoORaWojFBrg/exec'

interface UpdateData {
  rowIndex: number
  data: {
    tanggal: string
    alamat: string
    namaKlien: string
    noTelephone: string
    jenisPekerjaan: string
    teknisi: string
    statusBa: string
    statusPekerjaan: string
    statusPembayaran: string
    keterangan: string
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { rowIndex, data }: UpdateData = body
    
    console.log('=== UPDATE REQUEST DEBUG ===')
    console.log('Raw body:', JSON.stringify(body, null, 2))
    console.log('rowIndex:', rowIndex, 'type:', typeof rowIndex)
    console.log('data:', JSON.stringify(data, null, 2))
    console.log('data.alamat:', data?.alamat)
    console.log('data.namaKlien:', data?.namaKlien)
    console.log('===========================')

    // Validasi
    if (rowIndex === undefined || rowIndex < 0) {
      return NextResponse.json({
        success: false,
        error: 'Index baris tidak valid'
      }, { status: 400 })
    }

    // Jika Google Script URL tersedia
    if (GOOGLE_SCRIPT_URL) {
      try {
        const payload = {
          action: 'update',
          rowIndex: rowIndex + 2, // +2 karena row 1 adalah header, dan index mulai dari 0
          data: data
        }
        console.log('Sending to Google Script:', JSON.stringify(payload, null, 2))
        
        // Google Apps Script requires special handling for POST requests
        // Use FormData approach which works better with GAS redirects
        const formData = new FormData()
        formData.append('payload', JSON.stringify(payload))
        
        // Try direct JSON POST first
        const response = await fetch(GOOGLE_SCRIPT_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'text/plain;charset=utf-8',
          },
          body: JSON.stringify(payload),
          redirect: 'follow'
        })

        const responseText = await response.text()
        console.log('Google Script raw response:', responseText)
        
        let result
        try {
          result = JSON.parse(responseText)
        } catch {
          // If not JSON, might be HTML redirect page
          console.log('Response is not JSON, might be redirect page')
          
          // Try alternative approach - use GET with query params for update
          const encodedPayload = encodeURIComponent(JSON.stringify(payload))
          const getUrl = `${GOOGLE_SCRIPT_URL}?action=update&payload=${encodedPayload}`
          
          console.log('Trying GET approach...')
          const getResponse = await fetch(getUrl, {
            method: 'GET',
            redirect: 'follow'
          })
          const getText = await getResponse.text()
          console.log('GET response:', getText)
          
          try {
            result = JSON.parse(getText)
          } catch {
            return NextResponse.json({
              success: false,
              error: 'Gagal memproses response dari Google Script',
              debug: { getResponse: getText.substring(0, 500) }
            }, { status: 500 })
          }
        }
        
        console.log('Google Script parsed response:', result)

        if (result.success) {
          return NextResponse.json({
            success: true,
            message: 'Data berhasil diupdate'
          })
        } else {
          return NextResponse.json({
            success: false,
            error: result.error || 'Gagal mengupdate data'
          }, { status: 500 })
        }
      } catch (err) {
        console.error('Error calling Google Script:', err)
        return NextResponse.json({
          success: false,
          error: 'Gagal menghubungi Google Apps Script: ' + (err instanceof Error ? err.message : String(err))
        }, { status: 500 })
      }
    }

    // Jika tidak ada Google Script URL
    return NextResponse.json({
      success: false,
      error: 'Google Apps Script URL belum dikonfigurasi. Silakan gunakan fitur "Salin" dan paste manual ke Google Sheet.',
      data: data,
      rowIndex: rowIndex,
      copyFormat: `${data.tanggal}\t${data.alamat}\t${data.namaKlien}\t${data.noTelephone}\t${data.jenisPekerjaan}\t${data.teknisi}\t${data.statusBa}\t${data.statusPekerjaan}\t${data.statusPembayaran}\t${data.keterangan}`
    })

  } catch (err) {
    console.error('Update error:', err)
    return NextResponse.json({
      success: false,
      error: 'Terjadi kesalahan saat memproses data'
    }, { status: 500 })
  }
}
