import { NextRequest, NextResponse } from 'next/server'

const GOOGLE_SCRIPT_URL = process.env.GOOGLE_SCRIPT_URL || 'https://script.google.com/macros/s/AKfycbxs9WTyBb0-yNAtcw_srfqXzooReBFPLkIqsi6Ii5YtQWEzQCgxhMdS49qoORaWojFBrg/exec'
const GOOGLE_DRIVE_FOLDER_ID = '1_iyCrgekFmflt1h2wkXHCYrOGgvjHJBu'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const photo = formData.get('photo') as File | null
    const userIndex = formData.get('userIndex') as string | null
    const userName = formData.get('userName') as string || 'MBG'

    if (!photo) {
      return NextResponse.json({ 
        success: false, 
        error: 'Foto tidak ditemukan' 
      }, { status: 400 })
    }

    // Convert file to base64
    const bytes = await photo.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString('base64')
    const mimeType = photo.type || 'image/jpeg'

    // Generate filename with MBG prefix
    const timestamp = Date.now()
    const sanitizedName = userName.replace(/[^a-zA-Z0-9]/g, '_')
    const extension = photo.name.split('.').pop() || 'jpg'
    const fileName = `MBG_${sanitizedName}_${timestamp}.${extension}`

    // Send to Google Apps Script for upload to Drive
    const scriptPayload = {
      action: 'uploadPhoto',
      folderId: GOOGLE_DRIVE_FOLDER_ID,
      fileName: fileName,
      mimeType: mimeType,
      fileData: base64,
      userIndex: userIndex ? parseInt(userIndex) : -1
    }

    console.log('Uploading photo to Google Drive:', fileName)

    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(scriptPayload)
    })

    const result = await response.json()
    console.log('Google Script response:', result)

    if (result.success) {
      return NextResponse.json({
        success: true,
        photoUrl: result.photoUrl || result.url,
        fileName: fileName,
        message: 'Foto berhasil diupload ke Google Drive'
      })
    } else {
      return NextResponse.json({
        success: false,
        error: result.error || 'Gagal mengupload foto ke Google Drive'
      }, { status: 500 })
    }

  } catch (error) {
    console.error('Photo upload error:', error)
    return NextResponse.json({
      success: false,
      error: 'Terjadi kesalahan saat mengupload foto'
    }, { status: 500 })
  }
}
