# 📋 PANDUAN UPDATE GOOGLE APPS SCRIPT

## 🚨 MASALAH: "Action tidak dikenali: uploadPhoto"

Script Anda belum memiliki fitur upload foto. Ikuti langkah di bawah ini.

---

## LANGKAH 1: Buka Google Apps Script

👉 Klik link ini: https://script.google.com

Atau buka script Anda langsung:
https://script.google.com/d/AKfycbxACdP2xC_zdvPLjXF4v0aCdo2gPMSJWKb5x0ldJC7bKl7L6HdTF_wP1ofJyG_YfX0Q0w/edit

---

## LANGKAH 2: Hapus Semua Kode Lama

Di editor Google Apps Script:
1. Pilih semua kode (Ctrl+A)
2. Hapus semua (Delete/Backspace)

---

## LANGKAH 3: Copy Kode Baru

Copy SEMUA kode di bawah ini:

```javascript
// ============================================
// GOOGLE APPS SCRIPT - DASHBOARD SPPG
// ============================================

const SPREADSHEET_ID = '1Ntfc9QLJs6Al2nEHtydMiVurGTpwJLILUFjOQ1QyGXg';
const SHEET_SPPG_NAME = 'Sheet1';
const SHEET_USER_NAME = 'USER';

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    
    // Handle action: append (tambah data SPPG)
    if (data.action === 'append') {
      var sheet = ss.getSheetByName(SHEET_SPPG_NAME) || ss.getActiveSheet();
      sheet.appendRow([
        sheet.getLastRow(),
        data.data.tanggal || '',
        data.data.namaSppg || '',
        data.data.kepalaSppg || '',
        data.data.noTelephone || '',
        data.data.teknisi || '',
        data.data.statusBa || '',
        data.data.statusPekerjaan || '',
        data.data.statusPembayaran || '',
        data.data.keterangan || ''
      ]);
      return jsonResult({ success: true, message: 'Data SPPG berhasil ditambahkan' });
    }
    
    // Handle action: update (edit data SPPG)
    if (data.action === 'update') {
      var sheet = ss.getSheetByName(SHEET_SPPG_NAME) || ss.getActiveSheet();
      var rd = data.data;
      sheet.getRange(data.rowIndex, 2).setValue(rd.tanggal || '');
      sheet.getRange(data.rowIndex, 3).setValue(rd.namaSppg || '');
      sheet.getRange(data.rowIndex, 4).setValue(rd.kepalaSppg || '');
      sheet.getRange(data.rowIndex, 5).setValue(rd.noTelephone || '');
      sheet.getRange(data.rowIndex, 6).setValue(rd.teknisi || '');
      sheet.getRange(data.rowIndex, 7).setValue(rd.statusBa || '');
      sheet.getRange(data.rowIndex, 8).setValue(rd.statusPekerjaan || '');
      sheet.getRange(data.rowIndex, 9).setValue(rd.statusPembayaran || '');
      sheet.getRange(data.rowIndex, 10).setValue(rd.keterangan || '');
      return jsonResult({ success: true, message: 'Data SPPG berhasil diupdate' });
    }
    
    // Handle action: appendUser (tambah data USER)
    if (data.action === 'appendUser') {
      var sheet = findUserSheet(ss);
      if (!sheet) return jsonResult({ success: false, error: 'Sheet USER tidak ditemukan' });
      sheet.appendRow(data.data || []);
      return jsonResult({ success: true, message: 'Data USER berhasil ditambahkan' });
    }
    
    // Handle action: updateUser (edit data USER)
    if (data.action === 'updateUser') {
      var sheet = findUserSheet(ss);
      if (!sheet) return jsonResult({ success: false, error: 'Sheet USER tidak ditemukan' });
      var arr = data.data || [];
      for (var c = 0; c < arr.length; c++) {
        sheet.getRange(data.rowIndex, c + 1).setValue(arr[c]);
      }
      return jsonResult({ success: true, message: 'Data USER berhasil diupdate' });
    }
    
    // Handle action: uploadPhoto (UPLOAD FOTO KE GOOGLE DRIVE) ⭐ BARU
    if (data.action === 'uploadPhoto') {
      return handleUploadPhoto(data, ss);
    }
    
    return jsonResult({ success: false, error: 'Action tidak dikenali: ' + data.action });
    
  } catch (error) {
    return jsonResult({ success: false, error: error.toString() });
  }
}

// ============================================
// FUNCTION: handleUploadPhoto
// ============================================
function handleUploadPhoto(data, ss) {
  try {
    var folderId = data.folderId || '1_iyCrgekFmflt1h2wkXHCYrOGgvjHJBu';
    var fileName = data.fileName || 'MBG_photo.jpg';
    var mimeType = data.mimeType || 'image/jpeg';
    var base64Data = data.fileData;
    var userIndex = data.userIndex;
    
    // Decode base64 to blob
    var decoded = Utilities.base64Decode(base64Data);
    var blob = Utilities.newBlob(decoded, mimeType, fileName);
    
    // Get Google Drive folder
    var folder;
    try {
      folder = DriveApp.getFolderById(folderId);
    } catch (e) {
      folder = DriveApp.getRootFolder();
    }
    
    // Create file in Google Drive
    var file = folder.createFile(blob);
    file.setName(fileName);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    
    // Get file URL
    var fileId = file.getId();
    var photoUrl = 'https://drive.google.com/uc?export=view&id=' + fileId;
    
    // Update USER sheet with photo URL
    if (userIndex && userIndex > 0) {
      var userSheet = findUserSheet(ss);
      if (userSheet) {
        // Find PHOTO column
        var lastCol = userSheet.getLastColumn();
        var headers = [];
        if (lastCol > 0) {
          headers = userSheet.getRange(1, 1, 1, lastCol).getValues()[0];
        }
        
        var photoCol = -1;
        for (var h = 0; h < headers.length; h++) {
          var header = headers[h].toString().toLowerCase();
          if (header.indexOf('photo') >= 0 || header.indexOf('foto') >= 0 || header.indexOf('gambar') >= 0) {
            photoCol = h + 1;
            break;
          }
        }
        
        // Create PHOTO column if not exists
        if (photoCol === -1) {
          photoCol = headers.length + 1;
          userSheet.getRange(1, photoCol).setValue('PHOTO');
        }
        
        // Set photo URL
        userSheet.getRange(userIndex + 1, photoCol).setValue(photoUrl);
      }
    }
    
    return jsonResult({
      success: true,
      photoUrl: photoUrl,
      fileId: fileId,
      fileName: fileName,
      message: 'Foto berhasil diupload ke Google Drive'
    });
    
  } catch (e) {
    return jsonResult({ success: false, error: 'Gagal upload: ' + e.toString() });
  }
}

// ============================================
// HELPER FUNCTIONS
// ============================================
function findUserSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_USER_NAME);
  if (sheet) return sheet;
  
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getSheetId() === 761571836) {
      return sheets[i];
    }
  }
  return null;
}

function jsonResult(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  return jsonResult({
    status: 'OK',
    message: 'Google Apps Script Dashboard SPPG aktif',
    version: '2.0',
    features: ['append', 'update', 'appendUser', 'updateUser', 'uploadPhoto'],
    timestamp: new Date().toISOString()
  });
}
```

---

## LANGKAH 4: Save & Deploy

1. **Save**: Klik icon diskette atau Ctrl+S
2. **Deploy**: Klik tombol "Deploy" → "New deployment"
3. **Type**: Pilih "Web app"
4. **Execute as**: Me
5. **Who has access**: Anyone
6. **Deploy**: Klik tombol Deploy
7. **Copy URL** yang muncul

---

## LANGKAH 5: Test

Buka URL script di browser, harusnya muncul:
```json
{
  "status": "OK",
  "message": "Google Apps Script Dashboard SPPG aktif",
  "version": "2.0",
  "features": ["append", "update", "appendUser", "updateUser", "uploadPhoto"]
}
```

---

## ✅ SELESAI!

Setelah update, buka kembali:
👉 https://my-project-pink-seven.vercel.app

Fitur upload foto akan berfungsi!
